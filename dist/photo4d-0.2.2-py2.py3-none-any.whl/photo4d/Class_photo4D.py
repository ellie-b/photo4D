''' 
Program XXX Part I

TODO:
    - add the possibility to treat each camera independently with the file MicMac-LocolChantierDescriptuer.xml
    Generate automaticaly this xml file based on the camera names, and number


'''

# import public library
import os, glob
from os.path import join as opj
import numpy as np
import pandas as pd
from typing import Union
from shutil import copyfile, rmtree, copytree
from distutils.dir_util import copy_tree

# Import project libary
import photo4d.Process as proc
import photo4d.Utils as utils
import photo4d.Detect_Sift as ds
import photo4d.Image_utils as iu


class Photo4d(object):
    # Class constants
    # folders
    IMAGE_FOLDER = 'Images'
    ORI_FOLDER = "Ori-Ini"
    ORI_FINAL = "Ori-Bascule"
    MASK_FOLDER = 'Masks'
    GCP_FOLDER = 'GCP'
    RESULT_FOLDER = "Results"
    # file names
    GCP_COORD_FILE_INIT = 'GCPs_coordinates.xml'
    GCP_COORD_FILE_FINAL = 'GCPs_pick-S3D.xml'
    DF_DETECT_FILE = 'df_detect.csv'
    SET_FILE = 'set_definition.txt'
    GCP_PRECISION=0.2 # GCP precision in m
    GCP_POINTING_PRECISION=10 # Pointing precision of GCPs in images (pixels)
    GCP_PICK_FILE = 'GCPs_pick.xml'
    GCP_PICK_FILE_2D = 'GCPs_pick-S2D.xml'
    GCP_DETECT_FILE = 'GCPs_detect-S2D.xml'
    GCP_NAME_FILE = 'GCPs_names.txt'
    shift=[410000, 6710000, 0]
    useMask=False
    # Parameters
    distortion_model="Figee"
    
    
    def __init__(self, project_path, ext='JPG'):
        if not os.path.exists(project_path):
            print("ERROR The path " + project_path + " doesn't exists")
            return
            
        # add main folder
        self.project_path = os.path.abspath(project_path)
        print("Creation of object photo4d on the folder " + self.project_path)
        
        # add camera folders
        if os.path.exists(opj(self.project_path, Photo4d.IMAGE_FOLDER)):
            self.cam_folders = [opj(self.project_path, Photo4d.IMAGE_FOLDER, cam) for cam in
                                os.listdir(opj(self.project_path, Photo4d.IMAGE_FOLDER))]
            self.nb_folders = len(self.cam_folders)
            self.cam_names = [x.split('/')[-1] for x in self.cam_folders].sort()
            print("Added {} camera folders : \n  {}".format(self.nb_folders, '\n  '.join(self.cam_folders)))
        else:
            print('You must create a folder "' + Photo4d.IMAGE_FOLDER + '/" containing your camera folders')
            return
            
        # =========================================================================
        # add picture sets
        picture_set_def = opj(self.project_path, Photo4d.SET_FILE)
        if os.path.exists(picture_set_def):
            self.sorted_pictures = utils.pictures_array_from_file(picture_set_def)
            print("Added picture sets from " + picture_set_def)
        else:
            self.sorted_pictures = None
        # set default selected set to the last one
        self.selected_picture_set = -1
        
        # =========================================================================
        # add initial orientation
        if os.path.exists(opj(self.project_path, Photo4d.ORI_FOLDER)):
            print("Added initial orientation")
            self.in_ori = opj(self.project_path, Photo4d.ORI_FOLDER)
        else:
            self.in_ori = None
            
        # =========================================================================
        # add image masks
        if os.path.exists(opj(self.project_path, Photo4d.MASK_FOLDER)):
            self.masks = opj(self.project_path, Photo4d.MASK_FOLDER)
            print("Masks created from ")  # todo add the set of masks (and ori)
        else:
            self.masks = None
            
        # add GCP initial files
        # =========================================================================
        if os.path.exists(opj(self.project_path, Photo4d.GCP_FOLDER, Photo4d.GCP_COORD_FILE_INIT)):
            self.gcp_coord_file = opj(self.project_path,Photo4d.GCP_FOLDER, Photo4d.GCP_COORD_FILE_INIT)
            print("Added gcp coordinates file")
        else:
            self.gcp_coord_file = None
        if os.path.exists(opj(self.project_path, Photo4d.GCP_FOLDER, Photo4d.GCP_NAME_FILE)):
            self.gcp_names = opj(self.project_path, Photo4d.GCP_FOLDER, Photo4d.GCP_NAME_FILE)
        else:
            self.gcp_names = None
            
        # extension of the images
        self.ext = ext
        
        # condition on picture dates, to process only a few sets
        self.cond = None
        
        # Create temp folder
        self.tmp_path = opj(self.project_path, "tmp")
        if not os.path.exists(self.tmp_path): 
            os.makedirs(self.tmp_path)

        
        
    def __str__(self):
        string = "\n=======================================================================\n" \
                 "Project Photo4d located at " + self.project_path + \
                 "\n======================================================================="
        string += "\n Contains {} camera folders : \n   {}".format(self.nb_folders, '\n   '.join(self.cam_folders))
        if self.sorted_pictures is None:
            string += "\n Pictures unsorted"
        else:
            string += "\n Pictures sorted in {} sets ".format(len(self.sorted_pictures))
            string += "\n The current selected set is {}".format(self.sorted_pictures[self.selected_picture_set][1:])
            
        string += "\n=======================================================================\n"
        if self.in_ori is not None:
            string += " Initial orientation computed"
            string += "\n=======================================================================\n"
            
        if self.masks is not None:
            string += " Masks done "
            string += "\n=======================================================================\n"
            
        if self.gcp_coord_file is not None:
            string += " Absolute coordinates of GCPs are given"
            if self.dict_image_gcp is not None:
                string += "\n GCPs image coordinates are computed "
            string += "\n=======================================================================\n"
            
        return string
    
    def sort_picture(self, time_interval=600):
        self.sorted_pictures = iu.sort_pictures(self.cam_folders, opj(self.project_path, Photo4d.SET_FILE),
                                                  time_interval=time_interval,
                                                  ext=self.ext)
        return self.sorted_pictures


    def check_picture_quality(self, luminosity_thresh=1, blur_thresh=6):
        '''
        Function to Check if pictures are not too dark and/or too blurry (e.g. fog)
        '''
        if self.sorted_pictures is None:
            print("ERROR You must launch the sort_pictures() method before check_pictures()")
            return
        self.sorted_pictures = iu.check_picture_quality(self.cam_folders, opj(self.project_path, Photo4d.SET_FILE),
                                                   self.sorted_pictures,
                                                   lum_inf=luminosity_thresh,
                                                   blur_inf=blur_thresh)
        return self.sorted_pictures

            
    def timeSIFT_orientation(self, resolution=5000, distortion_mode='Fraser', display=False, clahe=False,
                            tileGridSize_clahe=8):
        '''
        Function to initialize camera orientation of the reference set of images using the Micmac command Tapas

        :param resolution:
        '''
        # change from working dir to tmp dir
        os.chdir(self.tmp_path)
        
        # select the set of good pictures to estimate initial orientation
        
        
        for s in range(len(self.sorted_pictures)):
            if self.sorted_pictures[s, 1]:
                selected_line = self.sorted_pictures[s]
                
                for i in range(len(self.cam_folders)):
                    in_path = opj(self.cam_folders[i], selected_line[i + 2])
                    out_path = opj(self.tmp_path, selected_line[i + 2])
                    if clahe:
                        iu.process_clahe(in_path, tileGridSize_clahe, out_path=out_path)
                    else:
                        copyfile(in_path, out_path)

        # Execute mm3d command for orientation
        success, error = utils.exec_mm3d("mm3d Tapioca All {} {}".format(".*" + self.ext, resolution), display=display)
        success, error = utils.exec_mm3d(
            "mm3d Tapas {} {} Out={}".format(distortion_mode, ".*" + self.ext, Photo4d.ORI_FOLDER[4:]), display=display)

        ori_path = opj(self.project_path, Photo4d.ORI_FOLDER)
        if success == 0:
            # copy orientation file
            if os.path.exists(ori_path): rmtree(ori_path)
            copytree(opj(self.tmp_path, Photo4d.ORI_FOLDER), ori_path)
            self.in_ori = ori_path
        else:
            print("ERROR Orientation failed\nerror : " + str(error))

        os.chdir(self.project_path)

            
    def create_mask_masterIm(self, del_pictures=True, master_folder_id=0):
        '''
        Create a mask on the image of the master_folder_id for the selected set
        Note : Only the mask of the central (MASTER) image is necessary
        '''
        
        if not os.path.exists(self.tmp_path): os.makedirs(self.tmp_path)
        # select the set of good pictures to estimate initial orientation
        selected_line = self.sorted_pictures[self.selected_picture_set]
        in_path = opj(self.cam_folders[master_folder_id], selected_line[master_folder_id + 2])
        out_path = opj(self.tmp_path, selected_line[master_folder_id + 2])
        copyfile(in_path, out_path)
        ds.exec_mm3d('mm3d SaisieMasqQT {} Name=Mask.tif'.format(out_path))
        self.useMask=True
        
    def prepare_gcp_files(self, gcp_coords_file, file_format='N_X_Y_Z', display=True):
        '''
        Function to prepare GCP coordinate from a textfile to Micmac xml format. Make sure your text file format is correct
        '''

        if not os.path.exists(opj(self.project_path, Photo4d.GCP_FOLDER)):
            os.makedirs(opj(self.project_path, Photo4d.GCP_FOLDER))
            
        # copy coordinates file into the project
        path2txt = opj(self.project_path, Photo4d.GCP_FOLDER, Photo4d.GCP_COORD_FILE_INIT)[:-4] + ".txt"
        copyfile(gcp_coords_file, path2txt)
        
        success, error = utils.exec_mm3d('mm3d GCPConvert #F={} {}'.format(file_format, path2txt),
                                         display=display)
        if success == 0:
            self.gcp_coord_file = opj(self.project_path, Photo4d.GCP_FOLDER, Photo4d.GCP_COORD_FILE_INIT)
            gcp_table = np.loadtxt(path2txt, dtype=str)

            try:
                gcp_name = gcp_table[:, file_format.split('_').index("N")]
                np.savetxt(opj(self.project_path, Photo4d.GCP_FOLDER, Photo4d.GCP_NAME_FILE), gcp_name, fmt='%s',
                           newline=os.linesep)
                self.gcp_names = opj(self.project_path, Photo4d.GCP_FOLDER, Photo4d.GCP_NAME_FILE)
            except ValueError:  # todo add a coherent except
                print("ERROR prepare_GCP_files(): Check file format and file delimiter. Delimiter is any space")
        else:
            print("ERROR prepare_GCP_files(): Check file format and file delimiter. Delimiter is any space")
            return 0

    def prepare_Camera_file(self, cam_pos_file, file_format='N_X_Y_Z', display=False):
        '''

        :param cam_pos_file:
        :param file_format:
        :param display:
        :param cam_distance:
        :return:
        '''
        cam = pd.read_csv(os.path.join(self.project_path, cam_pos_file), sep=' ', names=(file_format.split('_')), skiprows=1)
        all_images = pd.DataFrame()
        for my_cam in self.cam_folders:
            df = pd.DataFrame()
            df['N'] = os.listdir(my_cam)
            df['X'] = np.repeat(cam.X.loc[cam.N.values == os.path.split(my_cam)[-1]].values, df.N.shape[0])
            df['Y'] = np.repeat(cam.Y.loc[cam.N.values == os.path.split(my_cam)[-1]].values, df.N.shape[0])
            df['Z'] = np.repeat(cam.Z.loc[cam.N.values == os.path.split(my_cam)[-1]].values, df.N.shape[0])

            all_images = all_images.append(df, ignore_index=True)
        #print(all_images)
        all_images = all_images[file_format.split('_')]
        Images_pos = 'Images_pos.txt'
        os.chdir(self.tmp_path)
        with open(Images_pos, 'w') as file:
            file.write('#F=' + ' '.join(file_format.split('_')) + '\n')
            all_images.to_csv(file, index=False, sep=' ', header=False, mode='a')

        # 1. convert CAM position textfile to xml with oriconvert
        commandConv = 'mm3d OriConvert #F={} {} RAWGNSS_N'.format(file_format, Images_pos,
                                                                        self.GCP_PICK_FILE_2D)
        print(commandConv)
        success, error = utils.exec_mm3d(commandConv)
        os.chdir(self.project_path)


    def pick_initial_gcps(self):
        '''
        Function to pick GCP locations on the reference set of images with no a priori.
        
        Pick few GCPs (3 to 5) that MicMac can do a rough estimate of the camera orientation. Then go to pick_gcp_basc() to pick all GCPs of known location
        '''        
        os.chdir(self.tmp_path)
        
        if self.gcp_coord_file is None or self.gcp_names is None:
            print("ERROR prepare_gcp_files must be applied first")
        gcp_path = opj(self.project_path, Photo4d.GCP_FOLDER)
        copy_tree(opj(gcp_path), opj(self.tmp_path))
        # select the set of image on which to pick GCPs manually
        selected_line = self.sorted_pictures[self.selected_picture_set]
        file_set = "("
        for i in range(len(self.cam_folders)):
            file_set += selected_line[i + 2] + "|"
        file_set = file_set[:-1] + ")"
            
        commandSaisieAppuisInitQt='mm3d SaisieAppuisInitQt "{}" Ini {} {}'.format(file_set, self.GCP_NAME_FILE,
                                                                   self.GCP_PICK_FILE)
        print(commandSaisieAppuisInitQt)
        utils.exec_mm3d(commandSaisieAppuisInitQt)
        
        # Go back from tmp dir to project dir        
        os.chdir(self.project_path)
        
        
    def pick_all_gcps(self, resolution=5000):
        '''
        Function to pick GCP locations on the reference set of images, with a predicted position.
        
        Pick all GCPs of known location.
        '''

        os.chdir(self.tmp_path)

        # select the set of image on which to pick GCPs manually
        selected_line = self.sorted_pictures[self.selected_picture_set]
        file_set = "("
        for i in range(len(self.cam_folders)):
            file_set += selected_line[i + 2] + "|"
        file_set = file_set[:-1] + ")"

        command='mm3d SaisieAppuisPredicQt "{}" Bascule-Ini {} {}'.format(file_set,
                                                                   self.GCP_COORD_FILE_INIT,
                                                                   self.GCP_PICK_FILE)
        print(command)        
        utils.exec_mm3d(command)

        # Go back from tmp dir to project dir        
        os.chdir(self.project_path)
        
    def compute_transform(self, doCampari=False, CAM_position=False, GCP_position=True):
        '''
        Function to apply the transformation computed from the GCPs to all images.
        
        Set doCampari=True once all points are input and you are ready to carry on.
        '''

        os.chdir(self.tmp_path)
        if GCP_position:
            CAM_position=False
        elif CAM_position:
            GCP_position=False
        elif not GCP_position and  not CAM_position:
            print('Must choose wither CAM position or GCP position')

        # select all the images
        file_set = ".*" + self.ext

        if GCP_position:
            commandBasc = 'mm3d GCPBascule {} Ini Bascule-Ini {} {}'.format(file_set,
                                                                       self.GCP_COORD_FILE_INIT,
                                                                       self.GCP_PICK_FILE_2D)
            print(commandBasc)
            utils.exec_mm3d(commandBasc)

            if(doCampari):
                command = 'mm3d Campari {} Bascule-Ini Bascule GCP=[{},{},{},{}] AllFree=1'.format(file_set, self.GCP_COORD_FILE_INIT, self.GCP_PRECISION, self.GCP_PICK_FILE_2D, self.GCP_POINTING_PRECISION)
                print(command)
                success, error  = utils.exec_mm3d(command)
                if success == 0:
                    # copy orientation file
                    ori_path = opj(self.project_path,self.ORI_FINAL)
                    if os.path.exists(ori_path): rmtree(ori_path)
                    copytree(opj(self.tmp_path, Photo4d.ORI_FINAL), ori_path)
                else:
                    print("ERROR Orientation failed\nerror : " + str(error))
        if CAM_position:
            # 2. Center bascule  from the orientation out of Tapas to RAWGNSS_N
            commandBasc = 'mm3d CenterBascule {} Ini RAWGNSS_N Bascule-Ini'.format(file_set)
            print(commandBasc)
            utils.exec_mm3d(commandBasc)

            if(doCampari):
                #mm3d Campari .*JPG Ground_Init_RTL Ground_RTL EmGPS=[RAWGNSS_N,5] AllFree=1 SH=_mini
                command = 'mm3d Campari {} Bascule-Ini Bascule EmGPS=[RAWGNSS_N,5] AllFree=1 SH=_mini'.format(file_set)
                print(command)
                success, error = utils.exec_mm3d(command)
                if success == 0:
                    # copy orientation file
                    ori_path = opj(self.project_path, self.ORI_FINAL)
                    if os.path.exists(ori_path): rmtree(ori_path)
                    copytree(opj(self.tmp_path, Photo4d.ORI_FINAL), ori_path)
                else:
                    print("ERROR Orientation failed\nerror : " + str(error))

        # Go back from tmp dir to project dir        
        os.chdir(self.project_path)
        
        

            
    def pick_ManualTiePoints(self):
        '''
        Function to pick additional points that can be set as 'GCPs'. These will get coordinates estimates based on camera orientation, and will be used in other set of images for triangulation.
        This way, we artificailly increase the number of GCPs, and use the selected set of reference images as the absolute reference to which other 3D model will be orientated against. 
        
        Pick as many points as possible that are landmarks across the all set of image.
        '''

        os.chdir(self.tmp_path)

        # select the set of image on which to pick GCPs manually
        selected_line = self.sorted_pictures[self.selected_picture_set]
        file_set = "("
        for i in range(len(self.cam_folders)):
            file_set += selected_line[i + 2] + "|"
        file_set = file_set[:-1] + ")"
            
        command='mm3d SaisieAppuisPredicQt "{}" Ori-Bascule {} {}'.format(file_set,
                                                                   self.GCP_COORD_FILE_INIT,
                                                                   self.GCP_PICK_FILE)
        print(command)        
        utils.exec_mm3d(command)
        self.gcp_coord_file = opj(self.project_path,Photo4d.GCP_FOLDER, Photo4d.GCP_COORD_FILE_FINAL)
        
        # Go back from tmp dir to project dir        
        os.chdir(self.project_path)


    def process_all_timesteps(self, master_folder_id=0, clahe=False, tileGridSize_clahe=8, 
                              zoomF=1, Ori='Bascule', DefCor=0.0, shift=None, keep_rasters=True, display=False):
        if self.sorted_pictures is None:
            print("ERROR You must apply sort_pictures() before doing anything else")
            return

        proc.process_all_timesteps(self.tmp_path, self.sorted_pictures, opj(self.project_path, Photo4d.RESULT_FOLDER),
                          clahe=clahe, tileGridSize_clahe=tileGridSize_clahe, zoomF=zoomF,
                          master_folder_id=master_folder_id, Ori=Ori, useMask=self.useMask, DefCor=DefCor,
                          shift=shift, keep_rasters=keep_rasters, display_micmac=display)


    
    def set_selected_set(self, img_or_index: Union[int, str]):
        if self.sorted_pictures is None:
            print("ERROR You must apply sort_pictures before trying to chose a set")
            return
        else:
            if type(img_or_index) == int:
                self.selected_picture_set = img_or_index
                print(
                    "\n The current selected set is now {}".format(self.sorted_pictures[self.selected_picture_set][2:]))
            elif type(img_or_index) == str:
                found, i = False, 0
                while (not found) and (i < len(self.sorted_pictures)):
                    if img_or_index in self.sorted_pictures[i]:
                        found = True
                        self.selected_picture_set = i
                        print("\n The current selected set is now {}".format(
                            self.sorted_pictures[self.selected_picture_set][2:]))
                    i += 1
                if not found:
                    print('image {} not in sorted_pictures'.format(img_or_index))

        

    def clean_up_tmp(self):
        '''
        Function to delete the working folder.
        '''
        try:
            rmtree(self.tmp_path)  
        except FileNotFoundError:
            pass
        except PermissionError:
            print("Permission Denied, cannot delete " + self.tmp_path)
        except OSError:
            pass      
                
                
                
if __name__ == "__main__":
    
    ## Initialyze the project
     myproj = Photo4d(project_path=r"F:\Kluane\Processing_workflow\photo4d_ftn_test")
    # myproj.sort_picture()
    # myproj.check_picture_quality()
    # myproj.prepare_gcp_files(r"C:\Users\lucg\Desktop\Test_V1_2019\GCPs_coordinates_manual.txt",file_format="N_X_Y_Z")
    
    ## Create a mask on one of the master images to limit the area where correlation is attempted
    # myproj.create_mask_masterIm(1)
    
    ## Compute tie points throughout the stack
    # myproj.timeSIFT_orientation()
    ## TODO : mask tie points
    
    ## Deal with GCPs
    ## Select a set to input GCPs
    # myproj.set_selected_set("DSC02728.JPG")
    ## Input GCPs in 3 steps
    # myproj.pick_initial_gcps()
    # myproj.compute_transform()
    # myproj.pick_all_gcps()
    ## Eventually, change selected set to add GCP imput to more image (n times):
        #myproj.compute_transform()
        #myproj.set_selected_set("DSC02871.JPG")
        #myproj.pick_all_gcps()        
    #myproj.compute_transform(doCampari=True)

    ## Do the dense matching
    # myproj.process_all_timesteps()
    
    ## Cleanup
    # myproj.clean_up_tmp()